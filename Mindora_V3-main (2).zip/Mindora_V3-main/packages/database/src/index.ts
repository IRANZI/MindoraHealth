import { Prisma, PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log:
      process.env.NODE_ENV === 'development'
        ? ['query', 'error', 'warn']
        : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

export { Prisma, PrismaClient };
export type {
  Appointment,
  AppointmentStatus,
  MoodEntry,
  PatientProfile,
  RefreshToken,
  SessionType,
  TherapistProfile,
  User,
  UserRole,
} from '@prisma/client';
