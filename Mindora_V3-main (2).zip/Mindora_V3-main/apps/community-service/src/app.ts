import express, {
  type NextFunction,
  type Request,
  type Response,
} from 'express';
import communityRoutes, { internalRouter } from './routes/community.routes.js';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import { swaggerSpec } from './docs/swagger.js';
import { publicRouteLimiter } from './middleware/rate-limit.js';

const app = express();

// Trust exactly one hop (Kong) so req.ip / express-rate-limit read the
// real client IP from X-Forwarded-For instead of Kong's own container IP.
app.set('trust proxy', 1);

// Helmet defaults, CSP included. swagger-ui-express loads its scripts from
// files and only needs inline styles, both allowed by the default policy.
// upgrade-insecure-requests is dropped so /docs still loads over plain HTTP
// (local dev, internal container traffic).
app.use(
  helmet({
    contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } },
  })
);

app.use(express.json());

// Swagger docs
app.use(
  '/docs',
  publicRouteLimiter,
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec)
);

// Export the raw spec as JSON so other tools can consume it
app.get('/docs.json', publicRouteLimiter, (_req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

app.get('/health', publicRouteLimiter, (req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.use('/api/v1/community', communityRoutes);

// Mounted at root, not under /api/v1/community — Kong's community-internal
// route forwards /internal/community/... unchanged (strip_path: false).
app.use(internalRouter);

app.get('/api/v1/community/health', publicRouteLimiter, (_req, res) => {
  res.status(200).json({ status: 'ok', service: 'community-service' });
});

// Catches errors forwarded via next(err) — including rejected promises
// from asyncHandler-wrapped routes — so a transient failure (e.g. a
// dropped DB connection) returns a 500 instead of crashing the process.
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

export default app;
